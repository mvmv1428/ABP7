import express from "express";
import { getUsers } from "../controllers/userController.js";
import { createUser } from "../controllers/createUserController.js";
import { updateUser } from "../controllers/updateUserController.js";
import { deleteUser } from "../controllers/deleteUserController.js";

const router = express.Router();

router.get("/usuarios", getUsers);
router.post("/usuarios", createUser);
router.put("/usuarios/:id", updateUser);
router.delete("/usuarios/:id", deleteUser);

export default router;