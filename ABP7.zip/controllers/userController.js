import User from "../models/User.js";

export const getUsers = async (req, res) =>{
    try {
        const users = await User.findAll();
        if (users.length === 0) {
            return res.status(404).json({
                message: "No existen usuarios"
            });
        }
        res.json(users);

    } catch (error) {
        console.error("Error al consultar usuarios", error);
        res.status(500).json({
            message: "Error al obtener usuarios"
        });
    }
};
